#ifndef DOUBLELINKEDLIST_H
#define DOUBLELINKEDLIST_H

#include <iostream>

// Forward declaration
template <class T>
class LinkedList;

// External operator<< declaration
template <class T>
std::ostream& operator<<(std::ostream &os, const LinkedList<T> &list);

template <class T>
class LinkedList {
private:
    struct Node {
        T data;
        Node* prev;
        Node* next;

        Node(const T& value, Node* p = nullptr, Node* n = nullptr)
            : data(value), prev(p), next(n) {}
    };

    Node* head;
    Node* tail;
    int   m_size;

    // Helper to copy from another list
    void copyFrom(const LinkedList& source);

    // Helper to free all nodes
    void freeList();

public:
    // Constructors / destructor / assignment
    LinkedList();                                      // default
    LinkedList(const LinkedList &source);              // copy ctor
    LinkedList(LinkedList &&source);          // move ctor
    ~LinkedList();                                     // destructor

    LinkedList& operator=(const LinkedList &source);   // copy assign
    LinkedList& operator=(LinkedList &&source); // move assign

    // Modifiers
    void push_front(T value);
    void push_back(T value);
    void push_at(T value, int pos);

    void pop_front();
    void pop_back();
    void pop_at(int pos);

    void RemoveOdd();   // remove elements at indices 1,3,5,etc
    void clear();       // remove all elements

    // Accessors
    T front() const;  // throws if empty
    T back()  const;  // throws if empty
    int  size()   const;
    bool empty()  const;

    // Comparisons
    bool operator==(const LinkedList &rhs) const;
    bool operator!=(const LinkedList &rhs) const;

    // Give operator<< friend access (for printing)
    friend std::ostream& operator<< <>(std::ostream &os, const LinkedList<T> &list);
};
#include "DoubleLinkedList.cpp"
#endif // LINKEDLIST_H
